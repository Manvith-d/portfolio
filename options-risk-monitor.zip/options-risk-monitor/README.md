# Options Risk Monitor

**Collect options data, calculate risk sensitivities, and prepare it for analysis.**

A Python options-data pipeline related to the Greek Shield project. It supports local market-data collection, Black–Scholes Greeks calculations, validation and retries, historical storage, and an optional Snowflake-loading workflow.

## Workflow

```mermaid
flowchart LR
    A[Yahoo Finance options] --> B[Collection and validation]
    B --> C[Greeks calculations]
    C --> D[Local files and historical storage]
    D --> E[Optional Snowflake loading]
    F[Daily scheduler] --> B
```

## Technology

Python · yfinance · Pandas · NumPy · SciPy · Snowflake Connector · python-dotenv · schedule. The original dependency set also includes Streamlit and Plotly.

## Start with local collection

```sh
pip install -r requirements.txt
python run_daily.py
```

Run from the repository directory. The daily entry point collects AAPL options and creates local outputs. An internet connection is required for live data.

## Implementation guide

| File | Purpose |
| --- | --- |
| `robust_pipeline.py` | Collection, Greeks, validation, retries, and historical storage |
| `run_daily.py` | Local daily collection entry point |
| `pipeline_local.py` | Alternative local workflow |
| `generate_sample_data.py` | Synthetic development data |
| `automated_daily_pipeline.py` | Combined collection and Snowflake loading |
| `run_scheduler.py` | Persistent daily schedule at 18:30, machine-local time |
| `.env.example` | Environment configuration template |

## Snowflake setup

Copy `.env.example` to `.env` and supply your own account configuration. The loaders expect existing databases, schemas, tables, and suitable permissions; they do not provision those resources. Review each loader’s target table and insert logic before use. Keep `.env` out of version control.

Several scripts are historical alternatives retained as development references. Dependencies preserve the original versions and may need adaptation to current market-data APIs.

## Related work

- [Greek Shield — expanded team implementation](https://github.com/LikhithNG/New-Greek-shield-)
- [Earlier Greek Shield pipeline](https://github.com/LikhithNG/Greek-shield)

This is an educational analytics prototype. Python syntax was checked during source preparation; live data calls and Snowflake writes were not executed as part of that preparation. Local credentials, logs, collected data, and caches are excluded.

---
Explore more work in [Manvith Reddy Dalli’s portfolio](https://manvith-reddy-dalli.roo7001.chatgpt.site/) · [LinkedIn](https://www.linkedin.com/in/manvith-reddy-dalli-38a06a257)
