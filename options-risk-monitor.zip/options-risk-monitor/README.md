# Options Risk Monitor

Python options-data collection and risk-analysis scripts, related to the Greek Shield project.

## Technologies
Python, yfinance, pandas, NumPy, SciPy, Snowflake Connector, python-dotenv, and schedule. The original requirements also include Streamlit and Plotly.

## Local collection
1. Create a Python virtual environment.
2. Install `pip install -r requirements.txt`.
3. Run `python run_daily.py` to collect AAPL options and create local outputs.

`robust_pipeline.py` provides collection, Greeks calculations, validation, retries, and historical storage. `pipeline_local.py` offers an alternative local workflow. `generate_sample_data.py` creates synthetic data for development.

## Snowflake workflow
Copy `.env.example` to `.env` and fill in your own values. The SQL-loading scripts expect an existing database, schemas, tables, and appropriate account permissions; this source snapshot does not provision those resources. Inspect table definitions and insert operations before running a loader against your database.

`automated_daily_pipeline.py` combines collection and loading. `run_scheduler.py` starts a persistent daily schedule at 18:30 in the machine's local time. Other loader and connection scripts are retained as development references.

## Related team repositories
- [Greek Shield](https://github.com/LikhithNG/New-Greek-shield-)
- [Earlier pipeline](https://github.com/LikhithNG/Greek-shield)

## Source release
Local environment files, credentials, logs, collected data, and caches are excluded. Connection settings in the legacy connection helper now use environment variables. Original source files remain unchanged outside this release copy.

## Validation and limitations
Python syntax checked. Live market-data requests and Snowflake writes have not been executed during portfolio preparation. Dependencies retain the original pinned versions. Some scripts are historical alternatives and may require adjustment for current external APIs. This repository is an educational risk analytics prototype.
